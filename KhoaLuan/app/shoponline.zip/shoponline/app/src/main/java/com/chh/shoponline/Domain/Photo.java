package com.chh.shoponline.Domain;

public class Photo {
    private int resId;
    public Photo(int resId){
        this.resId = resId;
    }
    public int getResId() {
        return resId;
    }

    public void setResId(int resId) {
        this.resId = resId;
    }
}
